import { LightningElement } from 'lwc';

export default class ConditionallyValue extends LightningElement {
  odd_even = false;
}