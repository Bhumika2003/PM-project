// Js File

import { LightningElement } from 'lwc';

export default class NavBarButton extends LightningElement {
     name = 'Bhumika';
    // greeting(){
    //     this.greeting_access();
    // }
   

    // greeting_access(){
    //     console.log(`Hello ${this.name}`)
    // }

}
