import { LightningElement } from 'lwc';

export default class ForEachLoopPract extends LightningElement {
    greetToAll = ["Mahi","Sneha","Shruti","Riaj"]
    
}
console.log(greetToAll)